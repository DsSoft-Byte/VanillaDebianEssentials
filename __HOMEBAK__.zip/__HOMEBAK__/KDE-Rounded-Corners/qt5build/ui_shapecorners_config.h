#include <klocalizedstring.h>

/********************************************************************************
** Form generated from reading UI file 'shapecorners_config.ui'
**
** Created by: Qt User Interface Compiler version 5.15.4
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_SHAPECORNERS_CONFIG_H
#define UI_SHAPECORNERS_CONFIG_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QCheckBox>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QSlider>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_Form
{
public:
    QGridLayout *gridLayout;
    QVBoxLayout *verticalLayout;
    QSlider *roundness;
    QCheckBox *dsp;
    QSpacerItem *verticalSpacer;

    void setupUi(QWidget *Form)
    {
        if (Form->objectName().isEmpty())
            Form->setObjectName(QString::fromUtf8("Form"));
        Form->resize(400, 300);
        gridLayout = new QGridLayout(Form);
        gridLayout->setObjectName(QString::fromUtf8("gridLayout"));
        verticalLayout = new QVBoxLayout();
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        roundness = new QSlider(Form);
        roundness->setObjectName(QString::fromUtf8("roundness"));
        roundness->setMinimum(1);
        roundness->setMaximum(64);
        roundness->setPageStep(1);
        roundness->setOrientation(Qt::Horizontal);

        verticalLayout->addWidget(roundness);

        dsp = new QCheckBox(Form);
        dsp->setObjectName(QString::fromUtf8("dsp"));

        verticalLayout->addWidget(dsp);

        verticalSpacer = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout->addItem(verticalSpacer);


        gridLayout->addLayout(verticalLayout, 0, 0, 1, 1);


        retranslateUi(Form);

        QMetaObject::connectSlotsByName(Form);
    } // setupUi

    void retranslateUi(QWidget *Form)
    {
        Form->setWindowTitle(tr2i18n("Form", nullptr));
        dsp->setText(tr2i18n("Allow DSP (styleproject) to manage roundness", nullptr));
    } // retranslateUi

};

namespace Ui {
    class Form: public Ui_Form {};
} // namespace Ui

QT_END_NAMESPACE

#endif // SHAPECORNERS_CONFIG_H

