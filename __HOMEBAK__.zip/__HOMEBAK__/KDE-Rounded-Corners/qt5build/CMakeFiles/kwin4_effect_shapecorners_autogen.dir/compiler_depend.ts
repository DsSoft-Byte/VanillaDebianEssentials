# CMAKE generated file: DO NOT EDIT!
# Timestamp file for custom commands dependencies management for kwin4_effect_shapecorners_autogen.
