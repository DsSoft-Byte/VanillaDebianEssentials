For ROUNDED Edges on KWin DWM.

make
make install
