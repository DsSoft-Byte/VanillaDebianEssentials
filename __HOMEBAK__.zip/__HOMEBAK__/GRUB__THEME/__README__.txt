PASTE IN:
/usr/share/grub/themes/kawaiki
